Sample code for Chapter 10 - "Sequence hacking, hashing and slicing"

From the book "Fluent Python" by Luciano Ramalho (O'Reilly, 2015)
http://shop.oreilly.com/product/0636920032519.do
