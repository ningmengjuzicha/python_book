This file exists so that the directory is stored by git.
